package com.one.board;
import java.util.ArrayList;
import com.one.board.BoardDto;
public interface IDao {
	public ArrayList<BoardDto> list(int start, int end,String 
			searchKeyword,String selNum);

	
	public int selectBoardCount(String searchKeyword,String selNum);

	
	public void write2(String bname,
			String btitle, String bcontent, String fName);
	
	public BoardDto contentView2(String seqid);
		
	public void modify2(String bid, String bname,
			String btitle, String bcontent);
	
	public void delete2(String bid);
	
	
	public void stepup2(	String bgroup, String bstep);
	
	
}
