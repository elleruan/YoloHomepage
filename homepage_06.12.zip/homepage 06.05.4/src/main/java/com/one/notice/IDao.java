package com.one.notice;

import java.util.ArrayList;

import com.one.reply.ReplyDto;


public interface IDao {

	public ArrayList<NoticeDto> notice(int start, int end, String 
			searchKeyword,String selNum);
	
	public void write(String nname, String ntitle, String ncontent
						);
	
	public NoticeDto contentView(String seqid);
	
	public void upHit(String strid);
	
	public void modify(String nid, String nname,
			String ntitle, String ncontent);
	
	public void delete(String nid);
	
	public void stepup(	String ngroup, String nstep);
	
	public int selectNoticeCount(String searchKeyword,String selNum);
	
	public  int maxbid();
	
	public ArrayList<ReplyDto> linereple(String nid);
	
	public void linedel(String nid);
	
	public void replywrite(String rid,String rname,String rcontent);
	
	public void rmodify(String rid,String rname, String rcontent);
}
