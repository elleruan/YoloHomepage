package com.main.one;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RecipeController {
	@RequestMapping("/recipe")
	public String recipe() {
		System.out.println("recipe");
		
		
		return "recipe/recipe";
	}
	@RequestMapping("/recipeview")
	public String recipewrite() {
		System.out.println("recipewrite");
		
		
		return "recipe/recipe_view";
	}
	@RequestMapping("recipesee")
	public String reciprsee() {
		
		return"recipe/recipe_see";
	}
	
	
}
