package com.main.one;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.one.notice.IDao;
import com.one.notice.NoticeDto;
import com.one.notice.SearchVO;
import com.one.reply.ReplyDto;

@Controller
public class NoticeController {
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/notice")
	public String notice(HttpServletRequest request,
			SearchVO searchVo, Model model) {
		System.out.println("notice");
		
		String ntitle="";
		String ncontent="";
		String nname="";
		String all="";
		
		String[] nrdtitle=
				request.getParameterValues("searchType");
		
		if (nrdtitle!=null) {
			for (String val : nrdtitle) {
				if(val.equals("ntitle")) {
					model.addAttribute("ntitle","true");
					ntitle="ntitle";
				}else if(val.equals("ncontent")) {
					model.addAttribute("ncontent","true");
					ncontent="ncontent";
				}else if(val.equals("all")) {
					model.addAttribute("all","true");
					all="all";
				}else if(val.equals("nnmae")) {
					model.addAttribute("nname","true");
					nname="nname";
				}
			}
		}
		String searchKeyword=request.getParameter("sk");
		if(searchKeyword==null) {
			searchKeyword="";
		}
		
		IDao dao=sqlSession.getMapper(IDao.class);
		
		int total=0;

		if(ntitle.equals("ntitle") && ncontent.equals("")) {
			 total=dao.selectNoticeCount(searchKeyword ,"1" );
			System.out.println("go total >list1");
		}else if(ntitle.equals("") && ncontent.equals("ncontent")) {
			 total=dao.selectNoticeCount(searchKeyword, "2" );
			System.out.println("go total >list2");
		}else if(all.equals("all") ) {
			 total=dao.selectNoticeCount(searchKeyword, "3" );
			System.out.println("go total >list3");
		}else if(ntitle.equals("") && ncontent.equals("")) {
			 total=dao.selectNoticeCount(searchKeyword, "0" );
			System.out.println("go total >list0");
		}else if(all.equals("nname") ) {
			 total=dao.selectNoticeCount(searchKeyword, "4" );
			System.out.println("go total >list4");
		}
		
		String strPage=request.getParameter("page");
		
		model.addAttribute("searchKeyword",searchKeyword);
		
		if(strPage==null || strPage.equals("")) {
			strPage="1";
		}
		
		int page=Integer.parseInt(strPage);
		searchVo.setPage(page);
		
		searchVo.pageCalculate(total);

		int rowStart=searchVo.getRowStart();
		int rowEnd=searchVo.getRowEnd();
		
		if(ntitle.equals("ntitle") && ncontent.equals("")) {
			model.addAttribute("notice", dao.notice(rowStart,rowEnd,searchKeyword,"1"));
			model.addAttribute("totRowCnt", dao.selectNoticeCount(searchKeyword,"1"));
			System.out.println("gogo >list1");
		}else if(ntitle.equals("") && ncontent.equals("ncontent")) {
			model.addAttribute("notice", dao.notice(rowStart,rowEnd,searchKeyword,"2"));
			model.addAttribute("totRowCnt", dao.selectNoticeCount(searchKeyword,"2"));
			System.out.println("gogo >list2");
		}else if(all.equals("all") ) {
			model.addAttribute("notice", dao.notice(rowStart,rowEnd,searchKeyword,"3"));
			model.addAttribute("totRowCnt", dao.selectNoticeCount(searchKeyword,"3"));
			System.out.println("gogo >list3");
		}else if(ntitle.equals("") && ncontent.equals("")) {
			model.addAttribute("notice", dao.notice(rowStart,rowEnd,searchKeyword,"0"));
			model.addAttribute("totRowCnt", dao.selectNoticeCount(searchKeyword,"0"));
			System.out.println("gogo >list0");
		}else if(all.equals("nname") ) {
			model.addAttribute("nname", dao.notice(rowStart,rowEnd,searchKeyword,"4"));
			model.addAttribute("totRowCnt", dao.selectNoticeCount(searchKeyword,"4"));
			System.out.println("gogo >list4");
		}
		

		model.addAttribute("searchVo",searchVo);
		
		return "notice/notice";
	}
	
	@RequestMapping("/noticeinsert")
	public String noticeinsert() {
		System.out.println("insert");
		
		return "notice/notice_insert";
	}
	@RequestMapping("/write_view")
	public String write_view() {
		System.out.println("pass write_view()");
		return "notice/write_view";
	}
	@RequestMapping( "/write")
	public String write(HttpServletRequest request,
			Model model) throws Exception {
		System.out.println("write");
		
		String nname=request.getParameter("nname");
		String ntitle=request.getParameter("ntitle");
		String ncontent=request.getParameter("ncontent");
		
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.write(nname, ntitle, ncontent);
		
		return "redirect:notice";
	}
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request,SearchVO searchVo
			,Model model) {
		String nid=request.getParameter("nid");
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.upHit(nid);
		NoticeDto dto=dao.contentView(nid);
		model.addAttribute("content_view",dto);
		
		ArrayList<ReplyDto> replelist=dao.linereple(nid);
		for(ReplyDto var : replelist ) {
			System.out.println(var.getRcontent());
		}
		
		model.addAttribute("reply" , replelist);
		
		return "notice/content_view";
	}
	@RequestMapping("/addreple")
	public String addreple(HttpServletRequest request,
			Model model) {
		System.out.println("addreple");
		
		String rid=request.getParameter("rid");
		System.out.println("rid :"+rid);
		
		String rname=request.getParameter("rname");
		String rcontent=request.getParameter("addreple");
		
		IDao dao=sqlSession.getMapper(IDao.class);
		
		dao.replywrite(rid, rname, rcontent);
		
		model.addAttribute("nid",rid);
		
		return "redirect:content_view";
	}
	@RequestMapping("/linedel")
	public String linedel(HttpServletRequest request,
			Model model) {
		System.out.println("reply delete");
		
		String rid=request.getParameter("rid");
		String seq=request.getParameter("seq");
		
		IDao dao=sqlSession.getMapper(IDao.class);
		
		dao.linedel(seq);
		
		model.addAttribute("nid",rid);
		
		return "redirect:content_view";
	}
	@RequestMapping("/rmodify")
	public String rmodify(HttpServletRequest request,
			Model model) {
		System.out.println("rmodify");
		
		String rid=request.getParameter("rid");

		String rname=request.getParameter("rname");
		String rcontent=request.getParameter("rcontent");
		
		IDao dao=sqlSession.getMapper(IDao.class);
		
		dao.rmodify(rid, rname, rcontent);
		
		model.addAttribute("nid",rid);

		
		return "redirect:content_view";
	}
	
	@RequestMapping(value = "/modify",method = RequestMethod.POST)
	public String modify(HttpServletRequest request,
			Model model) {
		
		String nid=request.getParameter("nid");
		String nname=request.getParameter("nname");
		String ntitle=request.getParameter("ntitle");
		String ncontent=request.getParameter("ncontent");
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.modify(nid, nname, ntitle, ncontent);
		
		return "redirect:notice";

	}
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,
			Model model) {
		
	String nid=request.getParameter("nid");
	IDao dao=sqlSession.getMapper(IDao.class);
	dao.delete(nid);
	
	return "redirect:notice";
	}
}
