package com.main.one;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String main() {
		System.out.println("main");
		return "main2";
	}
@RequestMapping("/main")
public String main2() {
	
return "main";	
}
@RequestMapping("/test")
public String test(){
	return"jstest";
}
}
