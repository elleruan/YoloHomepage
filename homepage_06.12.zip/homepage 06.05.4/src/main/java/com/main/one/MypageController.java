package com.main.one;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MypageController {
	@RequestMapping("/mypage")
	public String mypage(){
		
		return "mypage/mypage";
	}
@RequestMapping("/mypagequ")
public String mypagequ() {
	
	return "mypage/mypage_question";
	
}
@RequestMapping("/mypagequ2")
public String mypagequ2() {
	
	return "mypage/mypage_question2";
	
}

@RequestMapping("/mypagemodify")
public String mypagemodify() {

	return "mypage/mypage_modify";
}
}
